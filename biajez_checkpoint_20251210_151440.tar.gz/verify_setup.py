import sys
import os

# Add current directory to path
sys.path.append(os.getcwd())

try:
    # Mock Env for instantiation BEFORE imports
    os.environ["AMADEUS_CLIENT_ID"] = "test"
    os.environ["AMADEUS_CLIENT_SECRET"] = "test"
    os.environ["DUFFEL_ACCESS_TOKEN"] = "test"
    os.environ["STRIPE_SECRET_KEY"] = "test"
    os.environ["OPENAI_API_KEY"] = "test"

    print("Verifying imports...")
    from app.models.models import Profile, LoyaltyProgram, Trip
    from app.services.flight_engine import FlightAggregator
    from app.services.booking_execution import BookingOrchestrator
    from app.services.hotel_engine import HotelEngine
    from app.ai.agent import AntigravityAgent
    from app.api.routes import router
    from app.main import app
    print("Imports successful.")

    print("Verifying Class Instantiation (Mocking Env)...")

    # Instantiate classes to check for init errors
    # Note: Client init might fail if they validate keys immediately, so we wrap in try/except specific to those libs if needed.
    # Amadeus client checks keys on init? Usually just stores them.
    # Duffel checks? 
    
    try:
        agent = AntigravityAgent()
        print("AntigravityAgent instantiated.")
    except Exception as e:
        print(f"AntigravityAgent init warning (expected if no real key): {e}")

    print("Verification Complete. Structure is valid.")

except ImportError as e:
    print(f"Import Error: {e}")
    sys.exit(1)
except Exception as e:
    print(f"Unexpected Error: {e}")
    sys.exit(1)
