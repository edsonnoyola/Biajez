import os
from amadeus import Client, ResponseError

def force_check():
    # Keys from the user's screenshot
    client_id = "8oOTBBDdcpDOY0rPgjt3YSLTIMz0WnAs"
    client_secret = "m1ESaL0UqVhDljQg"
    
    print(f"Testing Hardcoded Keys...")
    print(f"ID: {client_id}")
    print(f"Secret: {client_secret}")

    # Try PRODUCTION
    print("\nTesting against PRODUCTION (api.amadeus.com)...")
    try:
        amadeus = Client(
            client_id=client_id,
            client_secret=client_secret,
            hostname='production'
        )
        amadeus.reference_data.urls.checkin_links.get(airlineCode='BA')
        print("✅ SUCCESS! The keys work in Production.")
        print("Issue is likely in your .env file format.")
    except ResponseError as error:
        print(f"❌ Failed in Production: {error}")
        if error.response.status_code == 401:
            print("👉 Error 401: The keys are definitely invalid or NOT ACTIVE YET.")
            print("   (Amadeus says it takes 30 mins to activate)")
    except Exception as e:
        print(f"❌ Unexpected Error: {e}")

if __name__ == "__main__":
    force_check()
