import os
from amadeus import Client, ResponseError
from duffel_api import Duffel
from dotenv import load_dotenv

load_dotenv()

def check_amadeus():
    print("\n--- Checking Amadeus ---")
    client_id = os.getenv("AMADEUS_CLIENT_ID")
    client_secret = os.getenv("AMADEUS_CLIENT_SECRET")
    hostname = "production"
    
    print(f"Hostname: {hostname}")
    print(f"Client ID: {client_id[:4]}...{client_id[-4:] if client_id else 'None'}")
    
    try:
        amadeus = Client(
            client_id=client_id,
            client_secret=client_secret,
            hostname=hostname
        )
        # Simple call to test auth
        response = amadeus.reference_data.locations.get(
            keyword='LON',
            subType='CITY'
        )
        print("✅ Amadeus Connection Successful!")
    except ResponseError as error:
        print(f"❌ Amadeus Failed: {error}")
    except Exception as e:
        print(f"❌ Amadeus Error: {e}")

def check_duffel():
    print("\n--- Checking Duffel ---")
    token = os.getenv("DUFFEL_ACCESS_TOKEN")
    print(f"Token: {token[:4]}...{token[-4:] if token else 'None'}")
    
    try:
        duffel = Duffel(access_token=token)
        # Simple call
        aircraft = duffel.aircraft.list(limit=1)
        print("✅ Duffel Connection Successful!")
    except Exception as e:
        print(f"❌ Duffel Failed: {e}")

if __name__ == "__main__":
    check_amadeus()
    check_duffel()
