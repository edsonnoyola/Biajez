import asyncio
import os
from dotenv import load_dotenv
from app.services.flight_engine import FlightAggregator

load_dotenv()

async def verify_service():
    print("--- Verifying FlightAggregator Service ---")
    aggregator = FlightAggregator()
    
    origin = "MEX"
    dest = "MAD"
    date = "2025-12-13"
    
    print(f"Searching {origin} -> {dest} on {date}...")
    results = await aggregator.search_hybrid_flights(origin, dest, date, "ECONOMY")
    
    print(f"Found {len(results)} flights.")
    if results:
        print(f"First flight provider: {results[0].provider}")
        print(f"First flight price: {results[0].price} {results[0].currency}")
        print(f"First flight ID: {results[0].offer_id}")
    else:
        print("❌ No flights found.")

if __name__ == "__main__":
    asyncio.run(verify_service())
