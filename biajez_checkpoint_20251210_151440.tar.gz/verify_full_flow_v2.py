import asyncio
import os
import json
from datetime import datetime
from decimal import Decimal
from app.services.flight_engine import FlightAggregator

# Force env vars
from dotenv import load_dotenv
load_dotenv()

async def verify_serialization():
    print("1. Running Search...")
    aggregator = FlightAggregator()
    
    # Use a date far in future to ensure results
    date = "2026-01-15" 
    
    results = await aggregator.search_hybrid_flights(
        origin="LHR",
        destination="JFK",
        departure_date=date,
        cabin_class="ECONOMY"
    )
    
    if not results:
        print("ERROR: No results found. Cannot verify serialization.")
        return

    print(f"Found {len(results)} flights.")
    first_flight = results[0]
    
    # Simulate routes.py serialization
    # routes.py does: tool_result = [f.dict() for f in tool_result]
    # then: json.dumps(tool_result, default=str)
    
    flight_dict = first_flight.dict()
    
    print("\n2. Checking Data Types before JSON dump:")
    print(f"Price type: {type(flight_dict['price'])} (Value: {flight_dict['price']})")
    print(f"Segment 0 Dep Time type: {type(flight_dict['segments'][0]['departure_time'])} (Value: {flight_dict['segments'][0]['departure_time']})")
    
    json_output = json.dumps([flight_dict], default=str)
    print("\n3. JSON Output (What Frontend Receives):")
    print(json_output)
    
    # Check Date Format
    parsed = json.loads(json_output)
    dep_time_str = parsed[0]['segments'][0]['departure_time']
    print(f"\n4. Parsed Dep Time String: '{dep_time_str}'")
    
    if "T" not in dep_time_str:
        print("WARNING: Date string might be missing 'T' separator (YYYY-MM-DD HH:MM:SS). This can break 'new Date()' in JS.")
    else:
        print("SUCCESS: Date string is ISO formatted.")

if __name__ == "__main__":
    asyncio.run(verify_serialization())
