import React from 'react';
import { Plane, Check } from 'lucide-react';

interface FlightSegment {
    carrier_code: string;
    flight_number: string;
    departure_iata: string;
    arrival_iata: string;
    departure_time: string;
    arrival_time: string;
    duration: string;
}

interface FlightOffer {
    offer_id: string;
    provider: string;
    price: number;
    currency: string;
    segments: FlightSegment[];
    duration_total: string;
    cabin_class: string;
    refundable: boolean;
}

interface FlightCardProps {
    flight: FlightOffer;
    onBook: (offerId: string, provider: string, amount: number) => void;
}

export const FlightCard: React.FC<FlightCardProps> = ({ flight, onBook }) => {
    if (!flight.segments || flight.segments.length === 0) return null;
    const firstSegment = flight.segments[0];
    const lastSegment = flight.segments[flight.segments.length - 1];

    const formatTime = (isoString: string) => {
        return new Date(isoString).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    };

    return (
        <div className="bg-card/50 backdrop-blur-md border border-white/10 rounded-xl p-4 mb-3 hover:bg-card/80 transition-all shadow-lg max-w-sm w-full">
            <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center overflow-hidden">
                        <img
                            src={`https://pics.avs.io/200/200/${firstSegment.carrier_code}.png`}
                            alt={firstSegment.carrier_code}
                            className="w-full h-full object-contain"
                            onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.style.display = 'none';
                                // Create fallback icon if not exists
                                if (!target.parentElement?.querySelector('.fallback-icon')) {
                                    const icon = document.createElement('div');
                                    icon.className = 'fallback-icon text-gray-400';
                                    icon.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12h20"/><path d="M13 2l9 10-9 10"/><path d="M2 12l5-5m0 10l-5-5"/></svg>';
                                    target.parentElement?.appendChild(icon);
                                }
                            }}
                        />
                    </div>
                    <div>
                        <p className="font-bold text-sm">{firstSegment.carrier_code} {firstSegment.flight_number}</p>
                        <p className="text-xs text-gray-400 capitalize">{flight.cabin_class.replace('_', ' ')}</p>
                    </div>
                </div>
                <div className="text-right">
                    <p className="text-lg font-bold text-accent">${flight.price}</p>
                    <p className="text-xs text-gray-400">{flight.currency}</p>
                    <span className="text-[9px] uppercase tracking-wider text-gray-500 bg-white/5 px-1 rounded border border-white/5">
                        Via {flight.provider === 'SIMULATION' ? 'TEST' : flight.provider}
                    </span>
                </div>
            </div>

            <div className="flex items-center justify-between mb-4 relative">
                <div className="text-center">
                    <p className="text-xl font-bold">{firstSegment.departure_iata}</p>
                    <p className="text-xs text-gray-400">{formatTime(firstSegment.departure_time)}</p>
                </div>

                <div className="flex-1 px-4 flex flex-col items-center">
                    <p className="text-xs text-gray-500 mb-1">{flight.duration_total}</p>
                    <div className="w-full h-[1px] bg-gray-600 relative flex items-center justify-center">
                        <Plane size={12} className="text-gray-400 absolute bg-background px-1" />
                    </div>
                    <p className="text-[10px] text-accent mt-1">
                        {flight.segments.length > 1 ? `${flight.segments.length - 1} Stop` : 'Direct'}
                    </p>
                </div>

                <div className="text-center">
                    <p className="text-xl font-bold">{lastSegment.arrival_iata}</p>
                    <p className="text-xs text-gray-400">{formatTime(lastSegment.arrival_time)}</p>
                </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-white/5">
                <div className="flex gap-2">
                    {flight.refundable && (
                        <span className="flex items-center gap-1 text-[10px] bg-green-500/10 text-green-400 px-2 py-1 rounded-full">
                            <Check size={10} /> Flexible
                        </span>
                    )}
                </div>
                <button
                    onClick={() => onBook(flight.offer_id, flight.provider, flight.price)}
                    className="bg-primary hover:bg-primary/90 text-white text-xs px-4 py-2 rounded-lg transition-colors"
                >
                    Book Now
                </button>
            </div>
        </div>
    );
};
