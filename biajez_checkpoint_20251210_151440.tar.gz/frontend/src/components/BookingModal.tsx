import React, { useState } from 'react';
import { X, Check, Plane, Luggage, Armchair, Map } from 'lucide-react';
import { SeatMap } from './SeatMap';

interface BookingModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: (seatServiceId?: string, extraCost?: number, seatDesignator?: string) => void;
    flight: any;
    preferences: {
        seat: string;
        baggage: string;
    };
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, onConfirm, flight, preferences }) => {
    const [showSeatMap, setShowSeatMap] = useState(false);
    const [selectedSeat, setSelectedSeat] = useState<any>(null);

    if (!isOpen || !flight) return null;

    const segment = flight.segments[0];
    const basePrice = parseFloat(flight.price);
    const seatCost = selectedSeat?.price || 0;
    const totalPrice = (basePrice + seatCost).toFixed(2);

    const handleConfirm = () => {
        onConfirm(selectedSeat?.serviceId, seatCost, selectedSeat?.designator);
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
            <div className={`bg-gray-900/95 backdrop-blur-xl border border-white/10 w-full ${showSeatMap ? 'max-w-4xl' : 'max-w-md'} rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 transition-all`}>

                {/* Header */}
                <div className="bg-gradient-to-r from-primary to-accent p-6 text-white relative">
                    <button onClick={onClose} className="absolute top-4 right-4 p-2 hover:bg-white/20 rounded-full transition-colors">
                        <X size={20} />
                    </button>
                    <h2 className="text-2xl font-bold">Confirm Booking</h2>
                    <p className="opacity-90 text-sm mt-1">Review your AI-selected preferences</p>
                </div>

                <div className="flex flex-col md:flex-row">
                    {/* Left Side: Details */}
                    <div className="p-6 space-y-6 flex-1">
                        <div className="flex items-center justify-between p-4 bg-secondary/30 rounded-2xl border border-white/5">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400">
                                    <Plane size={20} />
                                </div>
                                <div>
                                    <p className="font-bold text-lg">{segment.departure_iata} → {segment.arrival_iata}</p>
                                    <p className="text-xs text-gray-400">{segment.carrier_code} • {flight.duration_total}</p>
                                </div>
                            </div>
                            <div className="text-right">
                                <p className="text-2xl font-bold text-green-400">${totalPrice}</p>
                                {seatCost > 0 && <p className="text-xs text-amber-400">(+${seatCost} seat)</p>}
                                <p className="text-xs text-gray-400">Total</p>
                            </div>
                        </div>

                        {/* Preferences Section */}
                        <div className="space-y-3">
                            <h3 className="text-sm font-medium text-gray-400 uppercase tracking-wider">Smart Preferences Applied</h3>

                            <div className="flex items-center gap-4 p-3 rounded-xl bg-white/5 border border-white/5">
                                <Armchair className="text-purple-400" size={24} />
                                <div className="flex-1">
                                    <p className="font-medium">Seat Selection</p>
                                    <p className="text-sm text-gray-400">
                                        {selectedSeat ? (
                                            <span className="text-green-400 font-bold">Selected: {selectedSeat.designator}</span>
                                        ) : (
                                            <>Auto-selected: <span className="text-white">{preferences.seat}</span></>
                                        )}
                                    </p>
                                </div>
                                <button
                                    onClick={() => setShowSeatMap(!showSeatMap)}
                                    className="px-3 py-1 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-medium transition-colors flex items-center gap-2"
                                >
                                    <Map size={14} />
                                    {showSeatMap ? "Hide Map" : "Select Seat"}
                                </button>
                            </div>

                            <div className="flex items-center gap-4 p-3 rounded-xl bg-white/5 border border-white/5">
                                <Luggage className="text-orange-400" size={24} />
                                <div>
                                    <p className="font-medium">Baggage</p>
                                    <p className="text-sm text-gray-400">Included: <span className="text-white">{preferences.baggage}</span></p>
                                </div>
                                <Check className="ml-auto text-green-500" size={18} />
                            </div>
                        </div>

                        {/* Action Button */}
                        <button
                            onClick={handleConfirm}
                            className="w-full py-4 bg-primary hover:bg-primary/90 text-white rounded-xl font-bold text-lg shadow-lg shadow-primary/25 transition-all active:scale-95"
                        >
                            Confirm & Pay ${totalPrice}
                        </button>
                    </div>

                    {/* Right Side: Seat Map (Conditional) */}
                    {showSeatMap && (
                        <div className="p-6 bg-black/20 border-l border-white/5 w-full md:w-[400px] flex flex-col">
                            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                                <Armchair size={20} /> Select Your Seat
                            </h3>
                            <div className="flex-1 overflow-y-auto min-h-[400px] bg-white/5 rounded-2xl">
                                <SeatMap offerId={flight.offer_id} onSelect={setSelectedSeat} />
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
