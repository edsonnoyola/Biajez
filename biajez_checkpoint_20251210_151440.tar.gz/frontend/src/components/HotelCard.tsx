import React from 'react';
import { MapPin, Star } from 'lucide-react';

interface HotelOffer {
    name: string;
    hotelId: string;
    rating: string;
    address: {
        cityName: string;
        countryCode: string;
    };
    price: {
        total: string;
        currency: string;
    };
}

interface HotelCardProps {
    hotel: HotelOffer;
    onBook: (offerId: string, amount: number) => void;
}

export const HotelCard: React.FC<HotelCardProps> = ({ hotel, onBook }) => {
    return (
        <div className="bg-card/50 backdrop-blur-md border border-white/10 rounded-xl p-4 mb-3 hover:bg-card/80 transition-all shadow-lg max-w-sm w-full">
            <div className="flex justify-between items-start mb-2">
                <div>
                    <h3 className="font-bold text-sm line-clamp-1">{hotel.name}</h3>
                    <div className="flex items-center gap-1 text-yellow-500 mt-1">
                        <Star size={12} fill="currentColor" />
                        <span className="text-xs">{hotel.rating}-Star</span>
                    </div>
                </div>
                <div className="text-right">
                    <p className="text-lg font-bold text-accent">${hotel.price.total}</p>
                    <p className="text-xs text-gray-400">{hotel.price.currency}</p>
                </div>
            </div>

            <div className="flex items-center gap-1 text-gray-400 text-xs mb-4">
                <MapPin size={12} />
                <span>{hotel.address.cityName}, {hotel.address.countryCode}</span>
            </div>

            <button
                onClick={() => onBook(hotel.hotelId, parseFloat(hotel.price.total))}
                className="w-full bg-secondary hover:bg-secondary/80 text-white text-xs px-4 py-2 rounded-lg transition-colors"
            >
                View Rooms
            </button>
        </div>
    );
};
