import os
from duffel_api import Duffel
from dotenv import load_dotenv

load_dotenv()

def test_search():
    print("Testing Duffel Search...")
    token = os.getenv("DUFFEL_ACCESS_TOKEN")
    duffel = Duffel(access_token=token, api_version="v2")

    print("Attempt 1: Builder Pattern")
    try:
        # Try Builder Pattern
        offers = (
            duffel.offer_requests.create()
            .slices([{"origin": "LHR", "destination": "JFK", "departure_date": "2025-12-25"}])
            .passengers([{"type": "adult"}])
            .cabin_class("economy")
            .return_offers()
            .execute()
        )
        print("✅ Builder Pattern Worked!")
        print(f"Offers raw: {offers}")
        print(f"Offers list: {list(offers.offers)}")
        print(f"Found {len(list(offers.offers))} offers.")
        return
    except Exception as e:
        print(f"❌ Builder Pattern Failed: {e}")

    print("\nAttempt 2: Kwargs Pattern")
    try:
        # Try Kwargs Pattern
        offers = duffel.offer_requests.create(
            slices=[{"origin": "LHR", "destination": "JFK", "departure_date": "2025-12-25"}],
            passengers=[{"type": "adult"}],
            cabin_class="economy",
            return_offers=True
        )
        print("✅ Kwargs Pattern Worked!")
        print(f"Found {len(offers.offers)} offers.")
        return
    except Exception as e:
        print(f"❌ Kwargs Pattern Failed: {e}")

if __name__ == "__main__":
    test_search()
