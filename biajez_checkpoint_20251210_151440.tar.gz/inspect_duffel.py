from duffel_api import Duffel
import inspect

print(inspect.getsource(Duffel.__init__))
