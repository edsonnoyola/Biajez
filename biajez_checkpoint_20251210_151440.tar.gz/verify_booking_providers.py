import asyncio
import os
import json
from app.services.flight_engine import FlightAggregator
from app.services.booking_execution import BookingOrchestrator
from app.db.database import SessionLocal
from app.models.models import Profile

# Force env vars
from dotenv import load_dotenv
load_dotenv()

async def verify_booking():
    print("=== 1. SEARCH (Duffel: LHR->JFK) ===")
    aggregator = FlightAggregator()
    date = "2026-02-15" # Future date
    
    results = await aggregator.search_hybrid_flights(
        origin="LHR",
        destination="JFK",
        departure_date=date,
        cabin_class="ECONOMY"
    )
    
    duffel_offer = next((f for f in results if f.provider == "DUFFEL"), None)
    
    if not duffel_offer:
        print("CRITICAL: No Duffel offers found. Cannot test booking.")
        return

    print(f"Found Duffel Offer: {duffel_offer.offer_id}")
    print(f"Price: {duffel_offer.price}")

    print("\n=== 2. PREPARE USER ===")
    db = SessionLocal()
    user_id = "test_verifier_user"
    profile = db.query(Profile).filter(Profile.user_id == user_id).first()
    if not profile:
        profile = Profile(
            user_id=user_id,
            legal_first_name="Test",
            legal_last_name="Verifier",
            email="test@example.com",
            phone_number="+15550000000",
            gender="M",
            dob="1990-01-01",
            passport_number="000000000",
            passport_expiry="2030-01-01",
            passport_country="US"
        )
        db.add(profile)
        db.commit()
    
    print(f"User ready: {user_id}")

    print("\n=== 3. EXECUTE BOOKING ===")
    orchestrator = BookingOrchestrator(db)
    
    try:
        # Note: Duffel Sandbox booking might fail if the offer is not "bookable" in sandbox 
        # (some offers are search-only). But LHR-JFK usually works.
        result = orchestrator.execute_booking(
            user_id=user_id,
            offer_id=duffel_offer.offer_id,
            provider="DUFFEL",
            amount=float(duffel_offer.price)
        )
        
        print("\n=== SUCCESS! BOOKING CONFIRMED ===")
        print(f"PNR: {result['pnr']}")
        print(f"Ticket URL: {result['ticket_url']}")
        
    except Exception as e:
        print(f"\n=== BOOKING FAILED ===")
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

if __name__ == "__main__":
    asyncio.run(verify_booking())
