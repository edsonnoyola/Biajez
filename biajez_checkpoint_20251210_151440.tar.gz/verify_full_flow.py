import asyncio
import os
from app.db.database import SessionLocal, engine
from app.models import models
from app.services.flight_engine import FlightAggregator
from app.services.booking_execution import BookingOrchestrator
from app.services.hotel_engine import HotelEngine
from datetime import datetime, timedelta

# Ensure tables exist
models.Base.metadata.create_all(bind=engine)

def load_env_file():
    env_path = ".env"
    if os.path.exists(env_path):
        with open(env_path, "r") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    key, value = line.split("=", 1)
                    # Remove quotes if present
                    value = value.strip("'").strip('"')
                    os.environ[key] = value

load_env_file()

async def verify_flow():
    db = SessionLocal()
    user_id = "test_verifier_user"
    
    print("--- 1. Setup User Profile ---")
    profile = db.query(models.Profile).filter(models.Profile.user_id == user_id).first()
    if not profile:
        profile = models.Profile(
            user_id=user_id,
            legal_first_name="Test",
            legal_last_name="Traveler",
            dob=datetime(1990, 1, 1).date(),
            gender="M",
            passport_number="P1234567",
            passport_expiry=datetime(2030, 1, 1).date(),
            passport_country="US",
            email="test@example.com",
            phone_number="+16465550100" # E.164 format required by Duffel
        )
        db.add(profile)
    else:
        # Update existing profile with valid phone
        profile.phone_number = "+16465550100"
        
    db.commit()
    print("User Ready.")

    print("\n--- 2. Search Flight (MEX -> MAD) ---")
    flight_agg = FlightAggregator()
    # Use a date 2 months in future for better availability in Test env
    future_date = (datetime.now() + timedelta(days=60)).strftime("%Y-%m-%d")
    
    flights = await flight_agg.search_hybrid_flights("MEX", "MAD", future_date)
    if not flights:
        print("❌ No flights found. Check API Keys or Amadeus Test Data availability.")
        return
    
    # Pick an Amadeus flight (usually has 'AMADEUS' in id)
    target_flight = next((f for f in flights if "AMADEUS" in f.offer_id), None)
    if not target_flight:
        print("⚠️ No Amadeus flights found (only Duffel?). Picking first available.")
        target_flight = flights[0]
    
    # Check attributes of target_flight to avoid errors
    carrier = getattr(target_flight, 'carrier', getattr(target_flight, 'airline', 'Unknown'))
    flight_num = getattr(target_flight, 'flight_number', '0000')
    
    print(f"✅ Selected Flight: {carrier} {flight_num} (${target_flight.price})")
    print(f"Offer ID: {target_flight.offer_id}")
    
    # DEBUG: Dump JSON for Frontend verification
    import json
    print("\n--- DEBUG: JSON STRUCTURE FOR FRONTEND ---")
    print(json.dumps(target_flight.dict(), default=str, indent=2))
    print("------------------------------------------\n")

    print("\n--- 3. Book Flight (Pricing -> Order -> Ticket) ---")
    orchestrator = BookingOrchestrator(db)
    try:
        # Provider is prefix of ID
        provider = target_flight.offer_id.split("::")[0]
        booking_result = orchestrator.execute_booking(
            user_id=user_id,
            offer_id=target_flight.offer_id,
            provider=provider,
            amount=target_flight.price
        )
        print("✅ Flight Booking Successful!")
        print(f"PNR: {booking_result['pnr']}")
        print(f"Ticket URL: {booking_result.get('ticket_url')}")
    except Exception as e:
        print(f"❌ Flight Booking Failed: {e}")
        # Continue to verify hotel even if flight fails? Maybe.
    
    print("\n--- 4. Search Hotel (Madrid) ---")
    hotel_engine = HotelEngine()
    # Test environment often has limited cities. MAD is usually supported.
    hotels = hotel_engine.search_hotels("MAD", future_date, (datetime.now() + timedelta(days=65)).strftime("%Y-%m-%d"))
    
    if not hotels:
        print("❌ No hotels found in MAD. Trying LON (London) as fallback for Test Env.")
        hotels = hotel_engine.search_hotels("LON", future_date, (datetime.now() + timedelta(days=65)).strftime("%Y-%m-%d"))
    
    if not hotels:
        print("❌ No hotels found in LON either. Stopping.")
        return

    target_hotel = hotels[0]
    print(f"✅ Selected Hotel: {target_hotel['name']} (${target_hotel['price']['total']})")
    
    print("\n--- 5. Book Hotel ---")
    # We need an offer ID. In our simplified engine, we might not have exposed it clearly in the list 
    # but let's assume the 'hotelId' or we need to fetch offers.
    # The current HotelEngine.search_hotels returns a list of mapped dicts.
    # Wait, the 'real' implementation in search_hotels (which I enabled) fetches offers and maps them.
    # But does it include the 'offerId' needed for booking?
    # Let's check the code I wrote for HotelEngine.search_hotels... 
    # It maps: "price": ..., "hotelId": ... 
    # It DOES NOT seem to map the specific 'offerId' from the Amadeus response into the top level dict 
    # that execute_booking expects.
    # I might need to fix HotelEngine to include 'offerId' in the returned dict.
    # For this script, I will inspect the result and see.
    
    # Let's try to book using what we have.
    # Actually, I should fix the code if it's missing.
    # But let's run the script first to see the structure.
    pass

if __name__ == "__main__":
    asyncio.run(verify_flow())
