import os
import requests
import json
from datetime import datetime, timedelta

# Mock Env for testing (ensure these are set in your shell or .env)
# os.environ["DUFFEL_ACCESS_TOKEN"] = "..."

def test_duffel_flow():
    print("1. Searching Duffel (LHR -> JFK)...")
    token = os.getenv("DUFFEL_ACCESS_TOKEN")
    if not token:
        print("ERROR: DUFFEL_ACCESS_TOKEN not set")
        return

    url = "https://api.duffel.com/air/offer_requests"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Duffel-Version": "v2"
    }
    
    # Future date
    date = (datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d")
    
    data = {
        "data": {
            "slices": [{"origin": "LHR", "destination": "JFK", "departure_date": date}],
            "passengers": [{"type": "adult"}],
            "cabin_class": "economy"
        }
    }
    
    res = requests.post(url, json=data, headers=headers)
    if res.status_code != 201:
        print(f"Search Failed: {res.text}")
        return

    offers = res.json()["data"]["offers"]
    if not offers:
        print("No offers found.")
        return
        
    print(f"Found {len(offers)} offers. Picking first one.")
    offer = offers[0]
    offer_id = offer["id"]
    passenger_id = offer["passengers"][0]["id"]
    amount = offer["total_amount"]
    
    print(f"Offer ID: {offer_id}")
    print(f"Passenger ID: {passenger_id}")
    print(f"Amount: {amount}")
    
    # 2. Booking
    print("\n2. Attempting Booking...")
    book_url = "https://api.duffel.com/air/orders"
    
    booking_data = {
        "data": {
            "selected_offers": [offer_id],
            "passengers": [{
                "id": passenger_id,
                "given_name": "Amelia",
                "family_name": "Earhart",
                "gender": "f",
                "title": "ms",
                "born_on": "1980-01-01",
                "email": "amelia@example.com",
                "phone_number": "+16505550100"
            }],
            "payments": [{"amount": amount, "currency": offer["total_currency"], "type": "balance"}]
        }
    }
    
    book_res = requests.post(book_url, json=booking_data, headers=headers)
    
    if book_res.status_code == 201:
        print("SUCCESS! Booking Confirmed.")
        print(json.dumps(book_res.json()["data"], indent=2))
    else:
        print(f"Booking FAILED: {book_res.status_code}")
        print(book_res.text)

if __name__ == "__main__":
    test_duffel_flow()
