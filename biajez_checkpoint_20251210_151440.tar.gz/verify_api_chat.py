import requests
import json

def verify_chat_api():
    url = "http://localhost:8000/v1/chat"
    headers = {"Content-Type": "application/json"}
    payload = {
        "messages": [{"role": "user", "content": "vuelo de mex a madrid del 13 al 15 de dic"}],
        "user_id": "demo-user"
    }
    
    print(f"Sending request to {url}...")
    try:
        response = requests.post(url, json=payload, headers=headers)
        print(f"Status Code: {response.status_code}")
        
        data = response.json()
        print("Response JSON (Truncated):")
        print(json.dumps(data, indent=2)[:2000]) # Print first 2000 chars
        
        # Check if tool_calls are present
        if "tool_calls" in data and data["tool_calls"]:
            print("\n✅ Tool Calls Found!")
            for tc in data["tool_calls"]:
                print(f"Tool: {tc['name']}")
                print(f"Args: {tc['arguments']}")
                # We can't see the *result* here because the backend executes it and appends it to history, 
                # but the *response* to the user usually summarizes it OR the frontend gets the tool result in a separate way?
                # Wait, in this architecture, the backend agent executes the tool and generates a response.
                # So we should look at 'response' text to see if it mentions flights.
        
        print(f"\nAgent Response: {data.get('response')}")

    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    verify_chat_api()
