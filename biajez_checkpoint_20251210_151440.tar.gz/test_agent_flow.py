import requests
import json
import time

def test_chat():
    url = "http://localhost:8000/v1/chat"
    headers = {"Content-Type": "application/json"}
    
    # Simulate User Message
    payload = {
        "user_id": "test_debug_user",
        "messages": [
            {"role": "user", "content": "Find me a flight from MEX to MAD for next month"}
        ]
    }
    
    print(f"--- Sending Request to {url} ---")
    start_time = time.time()
    
    try:
        response = requests.post(url, json=payload, timeout=60) # 60s timeout
        elapsed = time.time() - start_time
        
        print(f"Status: {response.status_code}")
        print(f"Time: {elapsed:.2f} seconds")
        
        if response.status_code == 200:
            data = response.json()
            print("\n--- Response Data ---")
            print(f"Server Response: {data.get('response')}")
            
            # Print structure summary
            if "messages" in data:
                print(f"Messages Count: {len(data['messages'])}")
                last_msg = data['messages'][-1]
                print(f"Last Message Role: {last_msg['role']}")
                print(f"Last Message Content Preview: {last_msg['content'][:200]}...")
                
                # Check for tool calls
                for msg in data['messages']:
                    if msg.get('role') == 'tool':
                        content = msg.get('content')
                        try:
                            tool_data = json.loads(content)
                            if isinstance(tool_data, list):
                                print(f"Tool Result: List of {len(tool_data)} items")
                            else:
                                print(f"Tool Result: {type(tool_data)}")
                        except:
                            print("Tool Result: Not JSON")
            else:
                print("Response:", data)
        else:
            print("Error Response:", response.text)
            
    except Exception as e:
        print(f"❌ Request Failed: {e}")

if __name__ == "__main__":
    test_chat()
