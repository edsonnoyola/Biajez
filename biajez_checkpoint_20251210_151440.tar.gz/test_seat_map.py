import os
import requests
import json
from dotenv import load_dotenv

load_dotenv()

def test_seat_map():
    print("--- Testing Duffel Seat Map (Raw) ---")
    token = os.getenv("DUFFEL_ACCESS_TOKEN")
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Duffel-Version": "v2"
    }
    
    # 1. Search
    print("Searching for flights...")
    url = "https://api.duffel.com/air/offer_requests"
    payload = {
        "data": {
            "slices": [{"origin": "LHR", "destination": "JFK", "departure_date": "2025-12-25"}],
            "passengers": [{"type": "adult"}],
            "cabin_class": "economy"
        }
    }
    
    res = requests.post(url, json=payload, headers=headers)
    if res.status_code != 201:
        print(f"❌ Search failed: {res.text}")
        return
        
    offers = res.json()["data"]["offers"]
    if not offers:
        print("❌ No offers found.")
        return
        
    for offer in offers:
        if offer['owner']['iata_code'] != "ZZ": continue # Prefer Duffel Airways
        
        print(f"Checking Offer ID: {offer['id']} ({offer['owner']['name']})")
        seat_url = f"https://api.duffel.com/air/seat_maps?offer_id={offer['id']}"
        res = requests.get(seat_url, headers=headers)
        
        if res.status_code == 200:
            seat_maps = res.json()["data"]
            if seat_maps:
                print(f"✅ Found {len(seat_maps)} seat maps!")
                for sm in seat_maps:
                    print(f"\nSegment: {sm['segment_id']}")
                    for cabin in sm['cabins']:
                        print(f"  Cabin: {cabin['cabin_class']}")
                        if cabin['rows']:
                            row = cabin['rows'][0]
                            print(f"    Row found with {len(row['sections'])} sections")
                            for section in row['sections']:
                                for element in section['elements']:
                                    if element['type'] == 'seat' and 'services' in element and element['services']:
                                        service = element['services'][0]
                                        print(f"      💰 Paid Seat {element['designator']}: {service['total_amount']} {service['total_currency']}")
                return
    print("❌ No seat maps found in any offer.")

if __name__ == "__main__":
    test_seat_map()
