import asyncio
import os
from dotenv import load_dotenv

load_dotenv()
os.environ["DATABASE_URL"] = "sqlite:///./antigravity.db"

from app.services.flight_engine import FlightAggregator
from app.services.booking_execution import BookingOrchestrator
from app.db.database import SessionLocal
from app.models.models import Profile

async def verify_booking():
    print("--- Verifying Booking Flow ---")
    
    # 1. Search
    aggregator = FlightAggregator()
    print("Searching flights...")
    results = await aggregator.search_hybrid_flights("LHR", "JFK", "2025-12-25", "ECONOMY")
    
    if not results:
        print("❌ No flights found to book.")
        return

    # Pick a Duffel flight
    duffel_flight = next((f for f in results if f.provider == "DUFFEL"), None)
    if not duffel_flight:
        print("❌ No Duffel flights found.")
        return

    print(f"Attempting to book: {duffel_flight.offer_id}")
    
    # 2. Book
    db = SessionLocal()
    try:
        # Ensure profile exists
        user_id = "demo-user"
        profile = db.query(Profile).filter(Profile.user_id == user_id).first()
        if not profile:
            print("Creating demo profile...")
            # ... (simplified profile creation if needed, but likely exists)
            pass 

        orchestrator = BookingOrchestrator(db)
        result = orchestrator.execute_booking(
            user_id=user_id,
            offer_id=duffel_flight.offer_id,
            provider="DUFFEL",
            amount=float(duffel_flight.price)
        )
        print("✅ Booking Successful!")
        print(result)
        
    except Exception as e:
        print(f"❌ Booking Failed: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    asyncio.run(verify_booking())
