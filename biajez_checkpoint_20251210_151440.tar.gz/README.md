# Antigravity Backend

This is the backend API for the Antigravity travel application.

## Setup

1.  **Install Dependencies**:
    ```bash
    pip install -r requirements.txt
    ```

2.  **Environment Variables**:
    Copy `.env.template` to `.env` and fill in your API keys (Amadeus, Duffel, Stripe, OpenAI, Supabase).

3.  **Run the Server**:
    ```bash
    uvicorn app.main:app --reload
    ```

## Usage

Once the server is running, open your browser to:
- **Interactive API Docs**: [http://localhost:8000/docs](http://localhost:8000/docs)
- **Alternative Docs**: [http://localhost:8000/redoc](http://localhost:8000/redoc)

## Features
- **Hybrid Flight Search**: Combines Amadeus and Duffel results.
- **Secure Booking**: Handles payments and PNR generation.
- **AI Agent**: Voice-optimized travel assistant.
