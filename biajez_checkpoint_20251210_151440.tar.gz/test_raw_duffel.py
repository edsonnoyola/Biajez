import os
import requests
from dotenv import load_dotenv

load_dotenv()

def test_raw():
    token = os.getenv("DUFFEL_ACCESS_TOKEN")
    url = "https://api.duffel.com/air/offer_requests"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Duffel-Version": "v2"
    }
    data = {
        "data": {
            "slices": [{"origin": "MEX", "destination": "MAD", "departure_date": "2025-12-13"}],
            "passengers": [{"type": "adult"}],
            "cabin_class": "economy"
        }
    }
    
    print(f"Testing with header: None")
    resp = requests.post(url, json=data, headers=headers)
    print(f"Status: {resp.status_code}")
    if resp.status_code == 201:
        data = resp.json()["data"]
        print(f"Offers found: {len(data['offers'])}")
        if data['offers']:
            print(f"First offer: {data['offers'][0]}")
    else:
        print(f"Error: {resp.text}")

if __name__ == "__main__":
    test_raw()
