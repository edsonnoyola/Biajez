import os
import requests
import json
from datetime import datetime, timedelta

# Force env vars
from dotenv import load_dotenv
load_dotenv()

def test_duffel_mex_cun():
    print("--- Testing Duffel Sandbox Coverage: MEX -> CUN ---")
    token = os.getenv("DUFFEL_ACCESS_TOKEN")
    
    url = "https://api.duffel.com/air/offer_requests"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Duffel-Version": "v2"
    }
    
    # Near-term date (Tomorrow)
    date = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    
    data = {
        "data": {
            "slices": [{"origin": "MEX", "destination": "CUN", "departure_date": date}],
            "passengers": [{"type": "adult"}],
            "cabin_class": "economy"
        }
    }
    
    print(f"Requesting MEX-CUN for {date}...")
    res = requests.post(url, json=data, headers=headers)
    
    if res.status_code != 201:
        print(f"API Error: {res.status_code}")
        print(res.text)
        return

    offers = res.json()["data"]["offers"]
    print(f"Offers Found: {len(offers)}")
    
    if len(offers) == 0:
        print("CONCLUSION: Duffel Sandbox DOES NOT support MEX-CUN.")
    else:
        print("CONCLUSION: Duffel Sandbox SUPPORTS MEX-CUN.")

if __name__ == "__main__":
    test_duffel_mex_cun()
