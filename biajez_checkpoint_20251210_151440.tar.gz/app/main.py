from dotenv import load_dotenv
load_dotenv() # Load env vars before anything else

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.models import models
from app.db.database import engine
from app.api import routes

# Create tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Antigravity API", version="1.0.0")

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(routes.router)

@app.get("/")
def read_root():
    return {"message": "Welcome to Antigravity API"}
