import asyncio
import os
from typing import List, Optional, Dict, Any
from datetime import datetime
from decimal import Decimal
from pydantic import BaseModel
from amadeus import Client, ResponseError
from duffel_api import Duffel

# --- DTOs ---
class FlightSegment(BaseModel):
    carrier_code: str
    flight_number: str
    departure_iata: str
    arrival_iata: str
    departure_time: datetime
    arrival_time: datetime
    duration: str

class AntigravityFlight(BaseModel):
    offer_id: str  # Unique ID for booking (provider_prefix + real_id)
    provider: str  # "AMADEUS" or "DUFFEL"
    price: Decimal
    currency: str
    segments: List[FlightSegment]
    duration_total: str
    cabin_class: str
    refundable: bool
    score: float = 0.0 # For sorting

    def dict(self, *args, **kwargs):
        d = super().dict(*args, **kwargs)
        # Manually serialize datetimes to ISO format for JSON safety
        for seg in d['segments']:
            if isinstance(seg['departure_time'], datetime):
                seg['departure_time'] = seg['departure_time'].isoformat()
            if isinstance(seg['arrival_time'], datetime):
                seg['arrival_time'] = seg['arrival_time'].isoformat()
        # Serialize Decimal to float or string
        if isinstance(d['price'], Decimal):
            d['price'] = float(d['price'])
        return d

# --- Service ---
# Simple persistent cache for offers (ID -> Full Object)
import json
CACHE_FILE = "offers_cache.json"

def load_cache():
    try:
        if os.path.exists(CACHE_FILE):
            with open(CACHE_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    return {}

def save_cache(cache):
    try:
        with open(CACHE_FILE, 'w') as f:
            json.dump(cache, f)
    except:
        pass

OFFER_CACHE = load_cache()

class FlightAggregator:
    def __init__(self):
        # Initialize Amadeus
        self.amadeus = Client(
            client_id=os.getenv("AMADEUS_CLIENT_ID"),
            client_secret=os.getenv("AMADEUS_CLIENT_SECRET"),
            hostname=os.getenv("AMADEUS_HOSTNAME", "test")
        )
        
        # Initialize Duffel (Test or Live)
        # Using v2 as confirmed by debug script
        self.duffel = Duffel(access_token=os.getenv("DUFFEL_ACCESS_TOKEN"), api_version="v2")

    async def search_hybrid_flights(
        self, 
        origin: str, 
        destination: str, 
        departure_date: str, 
        return_date: Optional[str] = None,
        cabin_class: str = "ECONOMY",
        airline: Optional[str] = None,
        time_of_day: str = "ANY"
    ) -> List[AntigravityFlight]:
        """
        Parallel execution of Amadeus and Duffel searches.
        """
        print(f"DEBUG: Searching flights - Origin: {origin}, Dest: {destination}, Date: {departure_date}, Cabin: {cabin_class}, Time: {time_of_day}")
        
        # FORCE MOCK IF ENABLED (Skip real APIs for speed/reliability in demo)
        if os.getenv("USE_MOCK_DATA", "true").lower() == "true":
            print("DEBUG: USE_MOCK_DATA=true. Returning mock flights immediately.")
            return self._get_mock_flights(origin, destination, departure_date, cabin_class, airline, time_of_day)

        # Define tasks
        amadeus_task = self._search_amadeus(origin, destination, departure_date, cabin_class, airline, return_date)
        duffel_task = self._search_duffel(origin, destination, departure_date, cabin_class, airline, return_date)
        
        # Run in parallel
        results = await asyncio.gather(amadeus_task, duffel_task, return_exceptions=True)
        
        # Flatten results
        final_results = []
        for res in results:
            if isinstance(res, list):
                final_results.extend(res)
            elif isinstance(res, Exception):
                print(f"Search Error: {res}")
                
        # FALLBACK: Simulation Mode if no flights found
        # Only if USE_MOCK_DATA is True (default)
        use_mock = os.getenv("USE_MOCK_DATA", "true").lower() == "true"
        
        if not final_results:
            print("DEBUG: No flights found from APIs. Returning empty list as per user request (NO SIMULATION).")
            return []
            
        # Deduplicate
        all_flights = self._deduplicate(final_results)
        
        # Scoring & Sorting
        # Base score = 0. Lower price is better, but we want to boost relevance.
        # We will sort by Score (Descending) then Price (Ascending).
        
        for flight in all_flights:
            score = 0
            
            # 1. Airline Preference
            if airline and flight.segments[0].carrier_code == airline:
                score += 100 # Huge boost for specific airline request
            
            # 2. Time of Day Preference
            if time_of_day != "ANY":
                dep_hour = flight.segments[0].departure_time.hour
                matches_time = False
                if time_of_day == "EARLY_MORNING" and 0 <= dep_hour < 6: matches_time = True
                elif time_of_day == "MORNING" and 6 <= dep_hour < 12: matches_time = True
                elif time_of_day == "AFTERNOON" and 12 <= dep_hour < 18: matches_time = True
                elif time_of_day == "EVENING" and 18 <= dep_hour < 22: matches_time = True
                elif time_of_day == "NIGHT" and 22 <= dep_hour <= 23: matches_time = True
                
                if matches_time:
                    score += 50 # Significant boost for time match
            
            flight.score = score

        # Sort: Primary = Score (Desc), Secondary = Price (Asc)
        all_flights.sort(key=lambda x: (-x.score, x.price))
        
        # Limit to top 10 to prevent payload issues
        return all_flights[:10]

    async def search_multicity(self, segments: List[Dict[str, str]], cabin_class="ECONOMY") -> List[AntigravityFlight]:
        """
        Search for multi-city flights using Duffel.
        segments: [{"origin": "MEX", "destination": "MAD", "date": "2025-12-15"}, ...]
        """
        print(f"DEBUG: Searching Multi-City: {segments}")
        
        # Map to Duffel slices
        duffel_slices = [{
            "origin": s["origin"], 
            "destination": s["destination"], 
            "departure_date": s["date"]
        } for s in segments]
        
        # Call Duffel with custom slices
        # We pass None for standard args as they are ignored when custom_slices is present
        return await self._search_duffel(None, None, None, cabin_class, custom_slices=duffel_slices)

    async def _search_amadeus(self, origin, dest, date, cabin, airline_filter=None, return_date=None):
        try:
            # Amadeus Search
            # Note: Amadeus SDK is synchronous, so this will block the event loop.
            # For production, consider running in a thread pool or using an async Amadeus client if available.
            if not return_date:
                response = self.amadeus.shopping.flight_offers_search.get(
                    originLocationCode=origin,
                    destinationLocationCode=dest,
                    departureDate=date,
                    adults=1,
                    travelClass=cabin,
                    max=10
                )
            else:
                response = self.amadeus.shopping.flight_offers_search.get(
                    originLocationCode=origin,
                    destinationLocationCode=dest,
                    departureDate=date,
                    returnDate=return_date,
                    adults=1,
                    travelClass=cabin,
                    max=10
                )
            
            if not response.data:
                return []
                
            flights = []
            for offer in response.data:
                # Basic mapping
                segments = []
                for itin in offer['itineraries']:
                    for seg in itin['segments']:
                        segments.append(FlightSegment(
                            carrier_code=seg['carrierCode'],
                            flight_number=seg['number'],
                            departure_iata=seg['departure']['iataCode'],
                            arrival_iata=seg['arrival']['iataCode'],
                            departure_time=datetime.fromisoformat(seg['departure']['at']),
                            arrival_time=datetime.fromisoformat(seg['arrival']['at']),
                            duration=seg['duration']
                        ))
                
                flights.append(AntigravityFlight(
                    offer_id=f"AMADEUS::{offer['id']}",
                    provider="AMADEUS",
                    price=Decimal(offer['price']['total']),
                    currency=offer['price']['currency'],
                    segments=segments,
                    duration_total=offer['itineraries'][0]['duration'],
                    cabin_class=cabin,
                    refundable=False 
                ))
            return flights
        except ResponseError as error:
            print(f"Amadeus Error: {error}")
            return []
        except Exception as e:
            print(f"Amadeus Unexpected Error: {e}")
            return []

    async def _search_duffel(self, origin, dest, date, cabin, airline_filter=None, return_date=None, custom_slices=None):
        try:
            import requests
            token = os.getenv("DUFFEL_ACCESS_TOKEN")
            url = "https://api.duffel.com/air/offer_requests"
            headers = {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
                "Duffel-Version": "v2"
            }
            
            if custom_slices:
                slices = custom_slices
            else:
                slices = [{"origin": origin, "destination": dest, "departure_date": date}]
                if return_date:
                    slices.append({"origin": dest, "destination": origin, "departure_date": return_date})

            data = {
                "data": {
                    "slices": slices,
                    "passengers": [{"type": "adult"}],
                    "cabin_class": (cabin or "economy").lower()
                }
            }
            
            response = await asyncio.to_thread(requests.post, url, json=data, headers=headers)
            
            if response.status_code != 201:
                print(f"Duffel Search Error: {response.text}")
                return []
                
            response_data = response.json()["data"]
            print(f"DEBUG: Duffel Raw Search Found {len(response_data['offers'])} offers")
            flights = []
            
            for offer in response_data['offers']:
                # Filter by airline if needed
                owner = offer['owner']['iata_code']
                if airline_filter and owner != airline_filter:
                    continue
                    
                segments = []
                for slice in offer['slices']:
                    for seg in slice['segments']:
                        segments.append(FlightSegment(
                            carrier_code=seg['operating_carrier']['iata_code'],
                            flight_number=seg.get('operating_carrier_flight_number') or "UNKNOWN",
                            departure_iata=seg['origin']['iata_code'],
                            arrival_iata=seg['destination']['iata_code'],
                            departure_time=datetime.fromisoformat(seg['departing_at']),
                            arrival_time=datetime.fromisoformat(seg['arriving_at']),
                            duration=seg['duration'] or "00:00"
                        ))
                
                # Store passenger ID in offer_id for booking retrieval if needed
                # Format: DUFFEL::offer_id::passenger_id
                passenger_id = offer['passengers'][0]['id']
                
                flights.append(AntigravityFlight(
                    offer_id=f"DUFFEL::{offer['id']}::{passenger_id}",
                    provider="DUFFEL",
                    price=Decimal(offer['total_amount']),
                    currency=offer['total_currency'],
                    segments=segments,
                    duration_total=offer['slices'][0]['duration'] or "00:00",
                    cabin_class=cabin,
                    refundable=False
                ))
            return flights
        except Exception as e:
            print(f"Duffel Error: {e}")
            return []

    def _get_mock_flights(self, origin, dest, date, cabin, airline_filter=None, time_of_day="ANY") -> List[AntigravityFlight]:
        """Generate mock flights for testing when APIs fail."""
        import random
        from datetime import datetime, timedelta
        
        mock_airlines = [
            {"code": "BA", "name": "British Airways"},
            {"code": "IB", "name": "Iberia"},
            {"code": "AM", "name": "Aeromexico"},
            {"code": "LH", "name": "Lufthansa"},
            {"code": "AF", "name": "Air France"}
        ]
        
        flights = []
        base_price = 800 if cabin == "ECONOMY" else 2500
        
        # Determine start hour based on time_of_day
        start_hour = 10
        if time_of_day == "EARLY_MORNING": start_hour = 4
        elif time_of_day == "MORNING": start_hour = 8
        elif time_of_day == "AFTERNOON": start_hour = 13
        elif time_of_day == "EVENING": start_hour = 18
        elif time_of_day == "NIGHT": start_hour = 22
        
        for i in range(5):
            # If airline filter is set and NOT 'ANY', force it
            effective_filter = airline_filter if airline_filter and airline_filter != "ANY" else None
            
            if effective_filter and (i < 4): # Ensure at least 4 match
                # Find the airline object
                airline = next((a for a in mock_airlines if a["code"] == effective_filter), {"code": effective_filter, "name": "Filtered Airline"})
            else:
                airline = random.choice(mock_airlines)
            
            # Apply Filter strict check
            if effective_filter and airline["code"] != effective_filter:
                continue
                
            try:
                # Generate time based on preference
                hour = (start_hour + i) % 24
                dep_time = datetime.strptime(f"{date} {hour:02d}:00", "%Y-%m-%d %H:%M")
            except:
                dep_time = datetime.now()
            
            arr_time = dep_time + timedelta(hours=11)
            
            flights.append(AntigravityFlight(
                offer_id=f"mock_{i}_{airline['code']}",
                provider="SIMULATION",
                price=Decimal(base_price + (i * 50)),
                currency="USD",
                segments=[FlightSegment(
                    carrier_code=airline["code"],
                    flight_number=f"{airline['code']}{100+i}",
                    departure_iata=origin,
                    arrival_iata=dest,
                    departure_time=dep_time,
                    arrival_time=arr_time,
                    duration="11h 00m"
                )],
                duration_total="11h 00m",
                cabin_class=cabin or "ECONOMY",
                refundable=True
            ))
            
        return flights

    def _deduplicate(self, flights: List[AntigravityFlight]) -> List[AntigravityFlight]:
        unique_map = {}
        
        for f in flights:
            if not f.segments:
                continue
                
            # Key: First Segment Flight Number + Departure Time
            # This is a heuristic. 
            key = f"{f.segments[0].carrier_code}{f.segments[0].flight_number}_{f.segments[0].departure_time}"
            
            if key in unique_map:
                existing = unique_map[key]
                # Keep lower price
                if f.price < existing.price:
                    unique_map[key] = f
            else:
                unique_map[key] = f
                
        return list(unique_map.values())
