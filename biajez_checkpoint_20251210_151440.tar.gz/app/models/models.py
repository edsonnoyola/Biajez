import uuid
from sqlalchemy import Column, String, Date, Enum, ForeignKey, Numeric, Integer
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
import enum
from app.db.database import Base

class GenderEnum(str, enum.Enum):
    M = "M"
    F = "F"
    X = "X"

class ProviderSourceEnum(str, enum.Enum):
    AMADEUS = "AMADEUS"
    DUFFEL = "DUFFEL"
    AMADEUS_HOTEL = "AMADEUS_HOTEL"

class TripStatusEnum(str, enum.Enum):
    TICKETED = "TICKETED"
    CONFIRMED = "CONFIRMED"
    CANCELLED = "CANCELLED"

class Profile(Base):
    __tablename__ = "profiles"

    user_id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    legal_first_name = Column(String, nullable=False)
    legal_last_name = Column(String, nullable=False)
    dob = Column(Date, nullable=False)
    gender = Column(Enum(GenderEnum), nullable=False)
    passport_number = Column(String, nullable=False) # Encrypted in application layer
    passport_expiry = Column(Date, nullable=False)
    passport_country = Column(String(2), nullable=False)
    known_traveler_number = Column(String, nullable=True)
    redress_number = Column(String, nullable=True)
    seat_preference = Column(String, default="ANY") # WINDOW, AISLE, ANY
    baggage_preference = Column(String, default="CARRY_ON") # CARRY_ON, CHECKED_1, CHECKED_2
    hotel_preference = Column(String, default="4_STAR") # 3_STAR, 4_STAR, 5_STAR
    flight_class_preference = Column(String, default="ECONOMY") # ECONOMY, PREMIUM_ECONOMY, BUSINESS, FIRST
    email = Column(String, nullable=True)
    phone_number = Column(String, nullable=True)
    preferred_seats = Column(String, nullable=True) # Comma-separated list of 3 seats
    preferred_hotels = Column(String, nullable=True) # Comma-separated list of hotels

    loyalty_programs = relationship("LoyaltyProgram", back_populates="user")

class LoyaltyProgram(Base):
    __tablename__ = "loyalty_programs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("profiles.user_id"), nullable=False)
    airline_code = Column(String, nullable=False)
    program_number = Column(String, nullable=False)
    tier_level = Column(String, nullable=True)

    user = relationship("Profile", back_populates="loyalty_programs")

class Trip(Base):
    __tablename__ = "trips"

    booking_reference = Column(String, primary_key=True) # PNR is unique
    user_id = Column(String, ForeignKey("profiles.user_id"), nullable=False)
    provider_source = Column(Enum(ProviderSourceEnum), nullable=False)
    total_amount = Column(Numeric(10, 2), nullable=False)
    status = Column(Enum(TripStatusEnum), nullable=False)
    invoice_url = Column(String, nullable=True)
