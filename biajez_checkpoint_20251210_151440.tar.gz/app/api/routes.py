from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.services.flight_engine import FlightAggregator
from app.services.booking_execution import BookingOrchestrator
from app.services.hotel_engine import HotelEngine
from app.ai.agent import AntigravityAgent
from app.models.models import Profile, LoyaltyProgram, Trip, TripStatusEnum
import json

router = APIRouter()

# Initialize Services (Singleton-ish for this scope)
flight_aggregator = FlightAggregator()
hotel_engine = HotelEngine()
agent = AntigravityAgent()

@router.get("/v1/search")
async def search_flights(origin: str, destination: str, date: str, cabin: str = "ECONOMY"):
    return await flight_aggregator.search_hybrid_flights(origin, destination, date, cabin)

@router.post("/v1/book")
def book_flight(user_id: str, offer_id: str, provider: str, amount: float, seat_service_id: str = None, db: Session = Depends(get_db)):
    # Auto-create profile if missing (for seamless demo)
    profile = db.query(Profile).filter(Profile.user_id == user_id).first()
    if not profile:
        print(f"DEBUG: Auto-creating profile for {user_id}")
        from datetime import datetime
        profile = Profile(
            user_id=user_id,
            legal_first_name="Demo",
            legal_last_name="User",
            email="demo@example.com",
            phone_number="+16505550100",
            gender="M",
            dob=datetime.strptime("1990-01-01", "%Y-%m-%d").date(),
            passport_number="000000000",
            passport_expiry=datetime.strptime("2030-01-01", "%Y-%m-%d").date(),
            passport_country="US"
        )
        db.add(profile)
        db.commit()

    orchestrator = BookingOrchestrator(db)
    return orchestrator.execute_booking(user_id, offer_id, provider, amount, seat_service_id)

@router.post("/v1/chat")
async def chat(request: Request, db: Session = Depends(get_db)):
    data = await request.json()
    messages = data.get("messages", [])
    user_id = data.get("user_id") # Assuming passed in header or body
    
    try:
        # 0. Fetch User Context
        profile = db.query(Profile).filter(Profile.user_id == user_id).first()
        user_context = ""
        if profile:
            user_context = f"""
            User Name: {profile.legal_first_name} {profile.legal_last_name}
            Seat Preference: {profile.seat_preference}
            Baggage Preference: {profile.baggage_preference}
            Preferred Seats (Specific): {profile.preferred_seats or "None"}
            Preferred Hotels: {profile.preferred_hotels or "None"}
            Loyalty Programs: {[f"{lp.airline_code}: {lp.program_number}" for lp in profile.loyalty_programs]}
            """
        
        # 1. Get AI Response
        response_message = await agent.chat(messages, user_context)
        
        # 2. Handle Tool Calls
        if response_message.tool_calls:
            # Append assistant message with tool calls
            messages.append(response_message.model_dump())
            
            for tool_call in response_message.tool_calls:
                function_name = tool_call.function.name
                arguments = json.loads(tool_call.function.arguments)
                tool_result = None
                
                if function_name == "search_hybrid_flights":
                    print(f"DEBUG: Agent calling search_hybrid_flights with args: {arguments}")
                    tool_result = await flight_aggregator.search_hybrid_flights(
                        arguments["origin"], 
                        arguments["destination"], 
                        arguments["date"], 
                        arguments.get("return_date"),
                        arguments.get("cabin", "ECONOMY"),
                        arguments.get("airline"),
                        arguments.get("time_of_day", "ANY")
                    )
                    print(f"DEBUG: Tool returned {len(tool_result)} flights")
                    # Serialize for LLM
                    tool_result = [f.dict() for f in tool_result]
                    print(f"DEBUG: Serialized {len(tool_result)} flights for LLM")
                    
                elif function_name == "search_multicity_flights":
                    tool_result = await flight_aggregator.search_multicity(
                        arguments["segments"],
                        arguments.get("cabin", "ECONOMY")
                    )
                    tool_result = [f.dict() for f in tool_result]
                    
                elif function_name == "book_flight_final":
                    # We need provider and amount. 
                    # In a real flow, the agent should have this context or we extract it from the offer_id if encoded.
                    # Our offer_id is "PROVIDER::ID".
                    offer_id = arguments["offer_id"]
                    provider = offer_id.split("::")[0]
                    # We need amount. For now, we fetch it or assume it's passed. 
                    # Limitation: The tool definition didn't ask for amount. 
                    # We'll assume we can look it up or it's in the context.
                    # For this exercise, we'll mock the amount lookup or pass a dummy.
                    amount = 100.00 # Placeholder
                    
                    orchestrator = BookingOrchestrator(db)
                    booking_result = orchestrator.execute_booking(user_id, offer_id, provider, amount)
                    tool_result = booking_result # Contains pnr, ticket_number, ticket_url
                    
                elif function_name == "google_hotels":
                    tool_result = hotel_engine.search_hotels(
                        arguments["city"], 
                        arguments["checkin"], 
                        arguments["checkout"],
                        arguments.get("amenities"),
                        arguments.get("room_type"),
                        arguments.get("landmark")
                    )
                    
                elif function_name == "add_loyalty_data":
                    # Add to DB
                    loyalty = LoyaltyProgram(
                        user_id=user_id,
                        airline_code=arguments["airline"],
                        program_number=arguments["number"]
                    )
                    db.add(loyalty)
                    db.commit()
                    tool_result = {"status": "success", "message": "Loyalty added"}

                elif function_name == "update_preferences":
                    if not profile:
                        # Create basic profile if not exists (for demo)
                        profile = Profile(
                            user_id=user_id, 
                            legal_first_name="Demo", 
                            legal_last_name="User",
                            dob="1990-01-01",
                            gender="M",
                            passport_number="Encrypted",
                            passport_expiry="2030-01-01",
                            passport_country="US"
                        )
                        db.add(profile)
                    
                    if "seat" in arguments:
                        profile.seat_preference = arguments["seat"]
                    if "baggage" in arguments:
                        profile.baggage_preference = arguments["baggage"]
                    if "preferred_seats" in arguments:
                        profile.preferred_seats = arguments["preferred_seats"]
                    if "preferred_hotels" in arguments:
                        profile.preferred_hotels = arguments["preferred_hotels"]
                    
                    db.commit()
                    tool_result = {"status": "success", "message": f"Preferences updated."}
                
                # Append Tool Message
                messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": json.dumps(tool_result, default=str)
                })
                
            # 3. Get Final Response
            final_response = await agent.chat(messages, user_context)
            # Append final response to history
            messages.append({"role": "assistant", "content": final_response.content})
            return {"response": final_response.content, "messages": messages}
            
        # No tool calls
        messages.append({"role": "assistant", "content": response_message.content})
        return {"response": response_message.content, "messages": messages}

    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"CRITICAL ERROR in /v1/chat: {e}")
        return {"response": f"System Error: {str(e)}", "messages": messages}

@router.get("/v1/profile/{user_id}")
def get_profile(user_id: str, db: Session = Depends(get_db)):
    profile = db.query(Profile).filter(Profile.user_id == user_id).first()
    if not profile:
        # Return empty/default structure if not found
        return {
            "legal_first_name": "",
            "legal_last_name": "",
            "dob": "",
            "passport_number": "",
            "passport_expiry": "",
            "passport_country": "",
            "known_traveler_number": "",
            "seat_preference": "ANY",
            "baggage_preference": "CARRY_ON",
            "email": "",
            "phone_number": ""
        }
    return profile

@router.put("/v1/profile/{user_id}")
async def update_profile(user_id: str, request: Request, db: Session = Depends(get_db)):
    data = await request.json()
    profile = db.query(Profile).filter(Profile.user_id == user_id).first()
    
    if not profile:
        profile = Profile(user_id=user_id)
        db.add(profile)
    
    # Update fields
    # Note: In a real app, use Pydantic models for validation
    if "legal_first_name" in data: profile.legal_first_name = data["legal_first_name"]
    if "legal_last_name" in data: profile.legal_last_name = data["legal_last_name"]
    from datetime import datetime
    if "dob" in data and data["dob"]: profile.dob = datetime.strptime(data["dob"], "%Y-%m-%d").date()
    if "passport_number" in data: profile.passport_number = data["passport_number"]
    if "passport_expiry" in data and data["passport_expiry"]: profile.passport_expiry = datetime.strptime(data["passport_expiry"], "%Y-%m-%d").date()
    if "passport_country" in data: profile.passport_country = data["passport_country"]
    if "known_traveler_number" in data: profile.known_traveler_number = data["known_traveler_number"]
    if "seat_preference" in data: profile.seat_preference = data["seat_preference"]
    if "baggage_preference" in data: profile.baggage_preference = data["baggage_preference"]
    if "email" in data: profile.email = data["email"]
    if "phone_number" in data: profile.phone_number = data["phone_number"]
    if "preferred_seats" in data: profile.preferred_seats = data["preferred_seats"]
    if "preferred_hotels" in data: profile.preferred_hotels = data["preferred_hotels"]
    
    # Set defaults for required fields if missing (hack for demo)
    if not profile.gender: profile.gender = "M" 
    
    db.commit()
    return {"status": "success", "profile": profile}

@router.get("/v1/trips/{user_id}")
def get_trips(user_id: str, db: Session = Depends(get_db)):
    trips = db.query(Trip).filter(Trip.user_id == user_id).all()
    return trips

@router.post("/v1/trips/{pnr}/cancel")
def cancel_trip(pnr: str, db: Session = Depends(get_db)):
    trip = db.query(Trip).filter(Trip.booking_reference == pnr).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    
    trip.status = TripStatusEnum.CANCELLED
    db.commit()
    return {"status": "success", "message": "Trip cancelled successfully"}

@router.get("/v1/seats/{offer_id}")
def get_seat_map(offer_id: str):
    # Extract real ID if needed (DUFFEL::ID)
    if "::" in offer_id:
        offer_id = offer_id.split("::")[1]
    
    import requests
    import os
    
    token = os.getenv("DUFFEL_ACCESS_TOKEN")
    url = f"https://api.duffel.com/air/seat_maps?offer_id={offer_id}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Duffel-Version": "v2"
    }
    
    try:
        res = requests.get(url, headers=headers)
        if res.status_code != 200:
            # If no seat map (e.g. not supported by airline), return empty
            return {"maps": []}
            
        return {"maps": res.json()["data"]}
    except Exception as e:
        print(f"Error fetching seats: {e}")
        return {"maps": []}
